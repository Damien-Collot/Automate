public enum TypeEtat {
    Initial,
    Transition,
    Final
}
